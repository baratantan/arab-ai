package com.vision.iptv

import java.net.URI
import java.net.URLDecoder

object M3uParser {
    private val attributes = Regex("([\\w-]+)=\"([^\"]*)\"")
    private val protocol = Regex("^(https?|rtsp)://", RegexOption.IGNORE_CASE)
    const val MAX_CHANNELS = 20_000

    fun direct(raw: String, title: String = "رابط مباشر", group: String = "عام", headers: Map<String, String> = emptyMap(), mime: String = ""): Channel {
        val parts = raw.trim().split('|', limit = 2)
        require(parts[0].length <= 8192 && protocol.containsMatchIn(parts[0])) { "الرابط يجب أن يبدأ بـ http:// أو https:// أو rtsp://" }
        require(!URI(parts[0]).host.isNullOrBlank()) { "عنوان المصدر غير صالح" }
        val merged = headers.toMutableMap()
        parts.getOrNull(1)?.split('&')?.forEach { pair ->
            val entry = pair.split('=', limit = 2)
            if (entry.size == 2) merged[URLDecoder.decode(entry[0], "UTF-8")] = URLDecoder.decode(entry[1], "UTF-8")
        }
        require(merged.size <= 20 && merged.all { (key, value) ->
            key.length <= 100 && value.length <= 4096 && !key.contains('\r') && !key.contains('\n') &&
                !value.contains('\r') && !value.contains('\n')
        }) { "ترويسات المصدر غير صالحة" }
        return Channel(title.ifBlank { "قناة" }, parts[0], group.ifBlank { "عام" }, headers = merged, mimeType = mime)
    }

    fun parse(text: String, baseUrl: String? = null): List<Channel> {
        val channels = mutableListOf<Channel>()
        var name = ""
        var group = ""
        var logo = ""
        var mime = ""
        var headers = mutableMapOf<String, String>()
        text.removePrefix("\uFEFF").lineSequence().forEach { raw ->
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF", true) -> {
                    val body = line.substringAfter(':')
                    var quoted = false
                    val comma = body.indexOfFirst { character ->
                        if (character == '"') quoted = !quoted
                        character == ',' && !quoted
                    }
                    val attrs = attributes.findAll(if (comma >= 0) body.take(comma) else body)
                        .associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                    name = (if (comma >= 0) body.substring(comma + 1) else "").trim().ifBlank { attrs["tvg-name"].orEmpty() }
                    group = attrs["group-title"].orEmpty().substringBefore(';')
                    logo = attrs["tvg-logo"].orEmpty()
                    headers = mutableMapOf()
                    mime = ""
                }
                line.startsWith("#EXTGRP:", true) -> group = line.substringAfter(':').trim()
                line.startsWith("#EXTVLCOPT:", true) -> {
                    val option = line.substringAfter(':').substringBefore('=').lowercase()
                    val key = when (option) {
                        "http-user-agent" -> "User-Agent"
                        "http-referrer", "http-referer" -> "Referer"
                        "http-origin" -> "Origin"
                        else -> ""
                    }
                    if (key.isNotEmpty()) headers[key] = line.substringAfter('=', "")
                }
                line.startsWith("#KODIPROP:inputstream.adaptive.manifest_type=", true) -> {
                    mime = when (line.substringAfter('=').lowercase()) {
                        "hls" -> "application/x-mpegURL"
                        "mpd" -> "application/dash+xml"
                        else -> ""
                    }
                }
                line.isEmpty() || line.startsWith('#') -> Unit
                else -> {
                    val absolute = if (protocol.containsMatchIn(line)) line else baseUrl?.let { URI(it).resolve(line).toString() }
                    if (absolute != null && protocol.containsMatchIn(absolute)) {
                        require(channels.size < MAX_CHANNELS) { "القائمة تتجاوز حد 20,000 قناة" }
                        channels += direct(absolute, name.ifBlank { "قناة " + (channels.size + 1) }, group, headers, mime).copy(logo = logo)
                    }
                    name = ""; group = ""; logo = ""; mime = ""; headers = mutableMapOf()
                }
            }
        }
        return channels
    }
}
