package com.vision.iptv

import org.json.JSONArray
import org.json.JSONObject

data class Channel(
    val name: String,
    val url: String,
    val group: String = "عام",
    val logo: String = "",
    val headers: Map<String, String> = emptyMap(),
    val mimeType: String = ""
) {
    fun toJson() = JSONObject().put("name", name).put("url", url)
        .put("group", group).put("logo", logo)
        .put("headers", JSONObject(headers)).put("mimeType", mimeType)

    companion object {
        fun fromJson(json: JSONObject): Channel {
            val raw = json.optJSONObject("headers") ?: JSONObject()
            val headers = raw.keys().asSequence().associateWith { raw.getString(it) }
            return Channel(json.optString("name", "قناة"), json.getString("url"),
                json.optString("group", "عام"), json.optString("logo"), headers, json.optString("mimeType"))
        }
    }
}

data class Playlist(val id: String, val name: String, val channels: List<Channel>) {
    fun toJson() = JSONObject().put("id", id).put("name", name)
        .put("channels", JSONArray().also { array -> channels.forEach { array.put(it.toJson()) } })
    companion object {
        fun fromJson(json: JSONObject): Playlist {
            val array = json.getJSONArray("channels")
            return Playlist(json.getString("id"), json.getString("name"),
                (0 until array.length()).map { Channel.fromJson(array.getJSONObject(it)) })
        }
    }
}

data class Library(val playlists: List<Playlist> = emptyList(), val favorites: Set<String> = emptySet(), val selectedId: String = "") {
    fun toJson() = JSONObject().put("selectedId", selectedId)
        .put("favorites", JSONArray(favorites.toList()))
        .put("playlists", JSONArray().also { array -> playlists.forEach { array.put(it.toJson()) } })
    companion object {
        fun fromJson(json: JSONObject): Library {
            val lists = json.optJSONArray("playlists") ?: JSONArray()
            val favorites = json.optJSONArray("favorites") ?: JSONArray()
            return Library((0 until lists.length()).map { Playlist.fromJson(lists.getJSONObject(it)) },
                (0 until favorites.length()).map { favorites.getString(it) }.toSet(), json.optString("selectedId"))
        }
    }
}
