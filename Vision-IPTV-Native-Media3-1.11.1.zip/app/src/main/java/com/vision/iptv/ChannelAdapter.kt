package com.vision.iptv

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ChannelAdapter(private val play: (Channel) -> Unit, private val toggle: (Channel) -> Unit) : RecyclerView.Adapter<ChannelAdapter.Holder>() {
    private var rows: List<Channel> = emptyList()
    private var favorites: Set<String> = emptySet()
    fun submit(channels: List<Channel>, stars: Set<String>) {
        rows = channels
        favorites = stars.toSet()
        notifyDataSetChanged()
    }
    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.channelName)
        val group: TextView = view.findViewById(R.id.channelGroup)
        val star: Button = view.findViewById(R.id.star)
    }
    override fun getItemCount() = rows.size
    override fun onCreateViewHolder(parent: ViewGroup, type: Int) =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.row_channel, parent, false))
    override fun onBindViewHolder(holder: Holder, position: Int) {
        val channel = rows[position]
        holder.name.text = channel.name
        holder.group.text = channel.group
        holder.star.text = if (channel.url in favorites) "★" else "☆"
        holder.star.contentDescription = if (channel.url in favorites) "إزالة من المفضلة" else "إضافة إلى المفضلة"
        holder.itemView.setOnClickListener { play(channel) }
        holder.star.setOnClickListener { toggle(channel) }
    }
}
