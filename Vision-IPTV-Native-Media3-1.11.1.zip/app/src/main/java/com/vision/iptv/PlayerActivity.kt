package com.vision.iptv

import android.app.Activity
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.ui.PlayerView
import androidx.media3.ui.TrackSelectionDialogBuilder
import org.json.JSONObject

@OptIn(UnstableApi::class)
class PlayerActivity : Activity() {
    private lateinit var channel: Channel
    private lateinit var playerView: PlayerView
    private var player: ExoPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var retries = 0
    private var position = 0L
    private var windowIndex = 0
    private var live = true
    private var autoplay = true
    private fun <T : View> view(id: Int): T = findViewById(id)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val payload = intent.getStringExtra("channel") ?: run { finish(); return }
        channel = Channel.fromJson(JSONObject(payload))
        position = savedInstanceState?.getLong("position") ?: 0L
        windowIndex = savedInstanceState?.getInt("window") ?: 0
        live = savedInstanceState?.getBoolean("live") ?: true
        autoplay = savedInstanceState?.getBoolean("autoplay") ?: true
        setContentView(R.layout.activity_player)
        Ui.applyInsets(this, view(R.id.root))
        playerView = view(R.id.player)
        view<TextView>(R.id.title).text = channel.name
        view<Button>(R.id.back).setOnClickListener { finish() }
        view<Button>(R.id.rotate).setOnClickListener {
            requestedOrientation = if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE)
                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
        view<Button>(R.id.retry).setOnClickListener { retries = 0; retry() }
        view<Button>(R.id.quality).setOnClickListener { tracks("الجودة", C.TRACK_TYPE_VIDEO) }
        view<Button>(R.id.audio).setOnClickListener { tracks("مسار الصوت", C.TRACK_TYPE_AUDIO) }
        view<Button>(R.id.subtitles).setOnClickListener { tracks("الترجمة", C.TRACK_TYPE_TEXT) }
    }

    override fun onStart() { super.onStart(); initialize() }

    private fun initialize() {
        val userAgent = channel.headers.entries.firstOrNull { it.key.equals("User-Agent", true) }?.value ?: "VisionIPTV/1.0"
        val http = DefaultHttpDataSource.Factory().setUserAgent(userAgent)
            .setAllowCrossProtocolRedirects(true).setConnectTimeoutMs(15_000).setReadTimeoutMs(20_000)
            .setDefaultRequestProperties(channel.headers)
        val sources = DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http))
            .setLoadErrorHandlingPolicy(DefaultLoadErrorHandlingPolicy(3))
        val buffers = DefaultLoadControl.Builder().setBufferDurationsMs(15_000, 50_000, 1_000, 2_000)
            .setTargetBufferBytes(64 * 1024 * 1024).setPrioritizeTimeOverSizeThresholds(false).build()
        val engine = ExoPlayer.Builder(this, DefaultRenderersFactory(this).setEnableDecoderFallback(true))
            .setMediaSourceFactory(sources).setLoadControl(buffers).build()
        player = engine
        playerView.player = engine
        engine.setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true)
        engine.setHandleAudioBecomingNoisy(true)
        engine.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) view<View>(R.id.errorBox).visibility = View.GONE
                if (state == Player.STATE_ENDED && engine.isCurrentMediaItemLive) showError("توقف البث من المصدر؛ يمكنك إعادة المحاولة")
            }
            override fun onPlayerError(error: PlaybackException) {
                val recoverable = error.errorCode in setOf(PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
                    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT)
                if (recoverable && retries < 3) {
                    val delay = 1000L shl retries
                    retries++
                    showError("انقطع الاتصال؛ إعادة محاولة " + retries + " من 3…")
                    handler.postDelayed({ retry() }, delay)
                } else {
                    val explanation = when (error.errorCode) {
                        PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS -> "رفض المصدر الطلب؛ تحقق من الاشتراك وUser-Agent وReferer"
                        PlaybackException.ERROR_CODE_DECODING_FAILED,
                        PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED -> "ترميز البث غير مدعوم على هذا الجهاز"
                        PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED,
                        PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED -> "صيغة البث غير صالحة أو غير مدعومة"
                        else -> "تعذر تشغيل البث؛ تحقق من المصدر والاتصال"
                    }
                    showError(explanation + "\nرمز الخطأ: " + error.errorCode)
                }
            }
        })
        val item = MediaItem.Builder().setUri(channel.url)
            .setMediaMetadata(MediaMetadata.Builder().setTitle(channel.name).build())
        val path = android.net.Uri.parse(channel.url).path.orEmpty().lowercase()
        val mime = channel.mimeType.ifBlank {
            when {
                path.endsWith(".m3u8") -> MimeTypes.APPLICATION_M3U8
                path.endsWith(".mpd") -> MimeTypes.APPLICATION_MPD
                path.endsWith(".ts") -> MimeTypes.VIDEO_MP2T
                else -> ""
            }
        }
        if (mime.isNotBlank()) item.setMimeType(mime)
        engine.setMediaItem(item.build())
        if (!live && position > 0L) engine.seekTo(windowIndex, position)
        engine.playWhenReady = autoplay
        engine.prepare()
    }

    private fun retry() {
        handler.removeCallbacksAndMessages(null)
        val engine = player ?: return
        view<View>(R.id.errorBox).visibility = View.GONE
        if (engine.isCurrentMediaItemLive) engine.seekToDefaultPosition()
        engine.prepare(); engine.play()
    }

    private fun tracks(title: String, type: Int) {
        val engine = player ?: return
        if (engine.currentTracks.groups.none { it.type == type && it.length > 0 }) {
            Toast.makeText(this, "لا توجد مسارات متاحة لهذا الخيار في البث", Toast.LENGTH_SHORT).show()
            return
        }
        TrackSelectionDialogBuilder(this, title, engine, type)
            .setAllowAdaptiveSelections(type == C.TRACK_TYPE_VIDEO)
            .setShowDisableOption(type == C.TRACK_TYPE_TEXT).build().show()
    }

    private fun showError(message: String) {
        view<TextView>(R.id.errorText).text = message
        view<View>(R.id.errorBox).visibility = View.VISIBLE
    }
    private fun remember() {
        player?.let { position = it.currentPosition; windowIndex = it.currentMediaItemIndex; live = it.isCurrentMediaItemLive; autoplay = it.playWhenReady }
    }
    override fun onSaveInstanceState(outState: Bundle) {
        remember()
        outState.putLong("position", position); outState.putInt("window", windowIndex)
        outState.putBoolean("live", live); outState.putBoolean("autoplay", autoplay)
        super.onSaveInstanceState(outState)
    }
    override fun onStop() {
        remember(); handler.removeCallbacksAndMessages(null)
        playerView.player = null; player?.release(); player = null
        super.onStop()
    }
}
