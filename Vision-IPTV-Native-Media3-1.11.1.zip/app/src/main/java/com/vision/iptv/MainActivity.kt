package com.vision.iptv

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var repository: PlaylistRepository
    private lateinit var adapter: ChannelAdapter
    private val playlists = mutableListOf<Playlist>()
    private val favorites = mutableSetOf<String>()
    private var selectedId = ""
    private var selectedGroup = ""
    private var busy = false
    private var queryTask: Runnable? = null
    private val active: Playlist? get() = playlists.find { it.id == selectedId } ?: playlists.firstOrNull()
    private fun <T : View> view(id: Int): T = findViewById(id)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Ui.applyInsets(this, view(R.id.root))
        repository = PlaylistRepository(applicationContext)
        adapter = ChannelAdapter(::play) { channel ->
            if (!favorites.add(channel.url)) favorites.remove(channel.url)
            renderChannels(); persist()
        }
        view<RecyclerView>(R.id.channels).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
            setHasFixedSize(true)
        }
        view<Button>(R.id.add).setOnClickListener {
            SourceDialogs.add(this, { url, name -> importSource { repository.importM3u(url, name) } }, ::pickFile,
                { server, user, pass, name -> importSource { repository.importXtream(server, user, pass, name) } })
        }
        view<Button>(R.id.direct).setOnClickListener { SourceDialogs.direct(this, ::play) }
        view<Button>(R.id.delete).setOnClickListener { deleteActive() }
        view<ToggleButton>(R.id.favorites).setOnCheckedChangeListener { _, _ -> renderChannels() }
        view<EditText>(R.id.search).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                queryTask?.let { handler.removeCallbacks(it) }
                queryTask = Runnable { renderChannels() }.also { handler.postDelayed(it, 180) }
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        setBusy(true, "جارٍ تحميل مكتبتك…")
        worker.execute {
            val result = runCatching { repository.load() }
            runOnUiThread {
                if (isDestroyed || isFinishing) return@runOnUiThread
                setBusy(false)
                result.onSuccess { library ->
                    playlists.addAll(library.playlists); favorites.addAll(library.favorites); selectedId = library.selectedId
                    renderSelectors()
                }.onFailure { renderSelectors(); showError("تعذر قراءة المكتبة المحفوظة؛ لم يتم حذف بياناتها") }
            }
        }
    }

    private fun setBusy(value: Boolean, message: String = "") {
        busy = value
        view<ProgressBar>(R.id.progress).visibility = if (value) View.VISIBLE else View.GONE
        view<Button>(R.id.add).isEnabled = !value
        view<Button>(R.id.delete).isEnabled = !value && playlists.isNotEmpty()
        if (message.isNotEmpty()) view<TextView>(R.id.status).text = message
    }

    private fun importSource(load: () -> Playlist) {
        if (busy) return
        setBusy(true, "جارٍ تحميل القنوات…")
        worker.execute {
            val result = runCatching(load)
            runOnUiThread {
                if (isDestroyed || isFinishing) return@runOnUiThread
                setBusy(false)
                result.onSuccess { playlist ->
                    playlists += playlist; selectedId = playlist.id; selectedGroup = ""
                    view<ToggleButton>(R.id.favorites).isChecked = false
                    view<EditText>(R.id.search).setText("")
                    renderSelectors(); persist()
                }.onFailure { showError(it.message?.takeIf { message -> !message.contains("://") } ?: "تعذر تحميل المصدر؛ تحقق من الاتصال وبيانات الاشتراك") }
            }
        }
    }

    private fun pickFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivityForResult(intent, 10)
    }

    @Deprecated("Android framework callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == 10 && resultCode == RESULT_OK && uri != null) {
            importSource {
                val text = contentResolver.openInputStream(uri)?.use { repository.readLimited(it) }
                    ?: error("تعذر فتح الملف")
                repository.fromText(text, "قائمة من الجهاز")
            }
        }
    }

    private fun spinner(id: Int, labels: List<String>, selected: Int, change: (Int) -> Unit) {
        view<Spinner>(id).apply {
            onItemSelectedListener = null
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_item, labels).apply {
                setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            setSelection(selected.coerceAtLeast(0), false)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) = Unit
                override fun onItemSelected(parent: AdapterView<*>?, item: View?, position: Int, rowId: Long) { change(position) }
            }
        }
    }

    private fun renderSelectors() {
        selectedId = active?.id.orEmpty()
        spinner(R.id.playlists, playlists.map { it.name }.ifEmpty { listOf("لا توجد قوائم") }, playlists.indexOfFirst { it.id == selectedId }) { index ->
            val next = playlists.getOrNull(index)?.id.orEmpty()
            if (next != selectedId) {
                selectedId = next; selectedGroup = ""; renderGroups(); persist()
            }
        }
        view<Button>(R.id.delete).isEnabled = !busy && playlists.isNotEmpty()
        renderGroups()
    }

    private fun renderGroups() {
        val groups = active?.channels.orEmpty().map { it.group }.distinct().sorted()
        val labels = listOf("كل التصنيفات") + groups
        spinner(R.id.groups, labels, if (selectedGroup.isEmpty()) 0 else (groups.indexOf(selectedGroup) + 1)) { index ->
            selectedGroup = groups.getOrNull(index - 1).orEmpty()
            renderChannels()
        }
        renderChannels()
    }

    private fun renderChannels() {
        val query = view<EditText>(R.id.search).text.toString().trim()
        val onlyFavorites = view<ToggleButton>(R.id.favorites).isChecked
        val all = active?.channels.orEmpty()
        val rows = all.filter { (selectedGroup.isEmpty() || it.group == selectedGroup) &&
            (!onlyFavorites || it.url in favorites) && (query.isEmpty() || it.name.contains(query, true)) }
        adapter.submit(rows, favorites)
        view<TextView>(R.id.empty).apply {
            visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
            text = if (playlists.isEmpty()) "أضف قائمة M3U أو اشتراك Xtream لبدء المشاهدة" else "لا توجد قنوات مطابقة"
        }
        if (!busy) view<TextView>(R.id.status).text = rows.size.toString() + " / " + all.size + " قناة"
    }

    private fun deleteActive() {
        val playlist = active ?: return
        AlertDialog.Builder(this).setTitle("حذف القائمة؟").setMessage(playlist.name)
            .setNegativeButton("إلغاء", null).setPositiveButton("حذف") { _, _ ->
                playlists.removeAll { it.id == playlist.id }; selectedGroup = ""
                val remainingUrls = playlists.flatMap { it.channels }.map { it.url }.toSet()
                favorites.retainAll(remainingUrls)
                renderSelectors(); persist()
            }.show()
    }

    private fun persist() {
        val snapshot = Library(playlists.toList(), favorites.toSet(), selectedId)
        worker.execute {
            val result = runCatching { repository.save(snapshot) }
            if (result.isFailure) runOnUiThread {
                if (!isDestroyed && !isFinishing) showError("تعذر حفظ التغييرات على الجهاز")
            }
        }
    }

    private fun play(channel: Channel) {
        startActivity(Intent(this, PlayerActivity::class.java).putExtra("channel", channel.toJson().toString()))
    }
    private fun showError(message: String) { view<TextView>(R.id.status).text = message }
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        worker.shutdown()
        super.onDestroy()
    }
}
