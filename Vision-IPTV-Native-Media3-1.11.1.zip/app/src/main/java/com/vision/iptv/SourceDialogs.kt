package com.vision.iptv

import android.app.Activity
import android.app.AlertDialog
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

object SourceDialogs {
    private data class Field(val hint: String, val required: Boolean = true, val password: Boolean = false, val url: Boolean = false)
    private fun form(activity: Activity, title: String, fields: List<Field>, submit: (List<String>) -> Unit) {
        val layout = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            val padding = (20 * resources.displayMetrics.density).toInt()
            setPadding(padding, padding / 2, padding, padding / 2)
        }
        val inputs = fields.map { field ->
            EditText(activity).apply {
                hint = field.hint
                isSingleLine = true
                inputType = when {
                    field.password -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                    field.url -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                    else -> InputType.TYPE_CLASS_TEXT
                }
                if (field.url || field.password) layoutDirection = View.LAYOUT_DIRECTION_LTR
                layout.addView(this)
            }
        }
        val scroll = ScrollView(activity).apply { addView(layout) }
        val dialog = AlertDialog.Builder(activity).setTitle(title).setView(scroll)
            .setNegativeButton("إلغاء", null).setPositiveButton("متابعة", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                var valid = true
                val values = inputs.mapIndexed { index, input ->
                    val value = if (fields[index].password) input.text.toString() else input.text.toString().trim()
                    if (fields[index].required && value.isBlank()) {
                        input.error = "هذا الحقل مطلوب"
                        valid = false
                    }
                    value
                }
                if (valid) {
                    try {
                        submit(values)
                        dialog.dismiss()
                    } catch (error: IllegalArgumentException) {
                        Toast.makeText(activity, error.message ?: "تحقق من البيانات", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
        dialog.show()
    }

    fun add(activity: Activity, url: (String, String) -> Unit, file: () -> Unit, xtream: (String, String, String, String) -> Unit) {
        AlertDialog.Builder(activity).setTitle("إضافة مصدر")
            .setItems(arrayOf("رابط قائمة M3U", "ملف M3U من الجهاز", "اشتراك Xtream Codes")) { _, index ->
                when (index) {
                    0 -> form(activity, "رابط قائمة M3U", listOf(Field("http://server/playlist.m3u", url = true), Field("اسم القائمة (اختياري)", false))) { url(it[0], it[1]) }
                    1 -> file()
                    2 -> form(activity, "Xtream Codes", listOf(Field("http://server:port", url = true), Field("اسم المستخدم"), Field("كلمة المرور", password = true), Field("اسم الاشتراك (اختياري)", false))) { xtream(it[0], it[1], it[2], it[3]) }
                }
            }.setNegativeButton("إلغاء", null).show()
    }

    fun direct(activity: Activity, play: (Channel) -> Unit) {
        form(activity, "تشغيل رابط مباشر", listOf(Field("http / https / rtsp", url = true), Field("User-Agent (اختياري)", false), Field("Referer (اختياري)", false, url = true))) { values ->
            val headers = mutableMapOf<String, String>()
            if (values[1].isNotBlank()) headers["User-Agent"] = values[1]
            if (values[2].isNotBlank()) headers["Referer"] = values[2]
            play(M3uParser.direct(values[0], headers = headers))
        }
    }
}
