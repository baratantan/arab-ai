package com.vision.iptv

import android.content.Context
import android.util.AtomicFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID

class PlaylistRepository(context: Context) {
    private val file = AtomicFile(File(context.filesDir, "library.json"))
    private val maxBytes = 12 * 1024 * 1024

    fun load(): Library = if (!file.baseFile.exists()) Library() else
        file.openRead().bufferedReader(Charsets.UTF_8).use { Library.fromJson(JSONObject(it.readText())) }

    fun save(library: Library) {
        val stream = file.startWrite()
        try {
            stream.write(library.toJson().toString().toByteArray(Charsets.UTF_8))
            file.finishWrite(stream)
        } catch (error: Exception) {
            file.failWrite(stream)
            throw error
        }
    }

    fun readLimited(stream: InputStream): String {
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var total = 0
        while (true) {
            val size = stream.read(buffer)
            if (size < 0) break
            total += size
            require(total <= maxBytes) { "المصدر أكبر من الحد المسموح: 12 MiB" }
            output.write(buffer, 0, size)
        }
        return output.toString("UTF-8")
    }

    private fun request(raw: String): Pair<String, String> {
        var url = URL(raw)
        repeat(6) {
            require(url.protocol == "http" || url.protocol == "https") { "يجب استخدام رابط HTTP أو HTTPS" }
            val connection = url.openConnection() as HttpURLConnection
            connection.instanceFollowRedirects = false
            connection.connectTimeout = 15_000
            connection.readTimeout = 20_000
            connection.setRequestProperty("User-Agent", "VisionIPTV/1.0")
            connection.setRequestProperty("Accept", "*/*")
            try {
                val code = connection.responseCode
                if (code in listOf(301, 302, 303, 307, 308)) {
                    val location = connection.getHeaderField("Location") ?: error("تحويل المصدر غير صالح")
                    url = URL(url, location)
                } else {
                    require(code in 200..299) { "تعذر تحميل المصدر (HTTP " + code + ")" }
                    require(connection.contentLength <= maxBytes) { "المصدر أكبر من 12 MiB" }
                    return connection.inputStream.use { readLimited(it) } to url.toString()
                }
            } finally {
                connection.disconnect()
            }
        }
        error("عدد تحويلات المصدر أكبر من المسموح")
    }

    fun importM3u(url: String, name: String): Playlist {
        val (text, finalUrl) = request(url)
        return fromText(text, name.ifBlank { URL(finalUrl).host }, finalUrl)
    }

    fun fromText(text: String, name: String, baseUrl: String? = null): Playlist {
        val channels = M3uParser.parse(text, baseUrl)
        require(channels.isNotEmpty()) { "لم نجد قنوات في القائمة؛ تأكد من أن الملف M3U وليس صفحة تسجيل دخول" }
        return Playlist(UUID.randomUUID().toString(), name.ifBlank { "قائمتي" }, channels)
    }

    fun importXtream(server: String, username: String, password: String, name: String): Playlist {
        val address = URL(server.trim().trimEnd('/'))
        require(address.protocol in listOf("http", "https") && address.host.isNotBlank() && address.userInfo == null) { "عنوان السيرفر غير صالح" }
        val base = address.toString().substringBefore('?').trimEnd('/')
        require(!base.endsWith(".php")) { "أدخل عنوان السيرفر فقط دون player_api.php أو get.php" }
        fun encode(value: String) = URLEncoder.encode(value, "UTF-8").replace("+", "%20")
        val user = encode(username)
        val pass = encode(password)
        val api = base + "/player_api.php?username=" + user + "&password=" + pass
        val account = JSONObject(request(api).first).optJSONObject("user_info")
            ?: error("رد غير صالح من سيرفر Xtream")
        require(account.optInt("auth", 0) == 1) { "اسم المستخدم أو كلمة المرور غير صحيحين" }
        require(account.optString("status", "Active").equals("Active", true)) { "الاشتراك غير نشط" }
        val categories = JSONArray(request(api + "&action=get_live_categories").first)
        val groupNames = (0 until categories.length()).associate { index ->
            val category = categories.getJSONObject(index)
            category.optString("category_id") to category.optString("category_name", "عام")
        }
        val streams = JSONArray(request(api + "&action=get_live_streams").first)
        require(streams.length() <= M3uParser.MAX_CHANNELS) { "المصدر يتجاوز حد 20,000 قناة" }
        val channels = (0 until streams.length()).mapNotNull { index ->
            val stream = streams.getJSONObject(index)
            val id = stream.optString("stream_id")
            if (!id.matches(Regex("[0-9]+"))) null else Channel(
                stream.optString("name", "قناة"),
                base + "/live/" + user + "/" + pass + "/" + id + ".ts",
                groupNames[stream.optString("category_id")] ?: "عام",
                stream.optString("stream_icon"), mimeType = "video/mp2t"
            )
        }
        require(channels.isNotEmpty()) { "لم نجد قنوات مباشرة في الاشتراك" }
        return Playlist(UUID.randomUUID().toString(), name.ifBlank { address.host }, channels)
    }
}
