package com.vision.iptv

import org.junit.Assert.*
import org.junit.Test

class M3uParserTest {
    @Test fun readsAttributesHeadersAndCommaInTitle() {
        val source = "#EXTM3U\n#EXTINF:-1 tvg-name=\"Fallback\" group-title=\"News\",News, HD\n#EXTVLCOPT:http-user-agent=Vision\nhttps://example.org/live.m3u8"
        val channel = M3uParser.parse(source).single()
        assertEquals("News, HD", channel.name)
        assertEquals("News", channel.group)
        assertEquals("Vision", channel.headers["User-Agent"])
    }
    @Test fun resolvesRelativePaths() {
        assertEquals("https://example.org/live/a.ts", M3uParser.parse("#EXTINF:-1,Test\n../live/a.ts", "https://example.org/lists/all.m3u").single().url)
    }
    @Test fun decodesUrlHeadersAndPreservesHttp() {
        val channel = M3uParser.direct("http://example.org/a.ts|User-Agent=Vision%20Player&Referer=https%3A%2F%2Fexample.org")
        assertEquals("http://example.org/a.ts", channel.url)
        assertEquals("Vision Player", channel.headers["User-Agent"])
        assertEquals("https://example.org", channel.headers["Referer"])
    }
    @Test fun resetsHeadersBetweenChannels() {
        val channels = M3uParser.parse("#EXTINF:-1,One\n#EXTVLCOPT:http-user-agent=A\nhttps://example.org/1.ts\n#EXTINF:-1,Two\nhttps://example.org/2.ts")
        assertTrue(channels[1].headers.isEmpty())
    }
    @Test(expected = IllegalArgumentException::class) fun rejectsUnsupportedProtocol() {
        M3uParser.direct("javascript:alert(1)")
    }
    @Test(expected = IllegalArgumentException::class) fun rejectsHeaderInjection() {
        M3uParser.direct("https://example.org/a.ts|User-Agent=bad%0D%0AHeader")
    }
}
